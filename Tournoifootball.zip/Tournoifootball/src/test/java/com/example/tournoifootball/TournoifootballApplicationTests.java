package com.example.tournoifootball;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TournoifootballApplicationTests {

    @Test
    void contextLoads() {
    }

}
