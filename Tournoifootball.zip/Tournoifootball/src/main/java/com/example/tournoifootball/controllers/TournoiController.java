package com.example.tournoifootball.controllers;

import com.example.tournoifootball.entities.Tournoi;
import com.example.tournoifootball.services.TournoiService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@AllArgsConstructor
@RestController
@RequestMapping("/tournois")
public class TournoiController {


    private TournoiService tournoiService;

    @GetMapping
    public List<Tournoi> getAllTournois() {
        return tournoiService.getAllTournois();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Tournoi> getTournoiById(@PathVariable Long id) {
        Tournoi tournoi = tournoiService.getTournoiById(id);
        if (tournoi != null) {
            return ResponseEntity.ok(tournoi);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Tournoi> createTournoi(@RequestBody Tournoi tournoi) {
        Tournoi createdTournoi = tournoiService.createTournoi(tournoi);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdTournoi);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Tournoi> updateTournoi(@PathVariable Long id, @RequestBody Tournoi tournoi) {
        Tournoi updatedTournoi = tournoiService.updateTournoi(id, tournoi);
        if (updatedTournoi != null) {
            return ResponseEntity.ok(updatedTournoi);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTournoi(@PathVariable Long id) {
        tournoiService.deleteTournoi(id);
        return ResponseEntity.noContent().build();
    }
}
