package com.example.tournoifootball.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.tournoifootball.entities.Stade;
import com.example.tournoifootball.entities.Matche;
import com.example.tournoifootball.services.StadeService;

@RestController
@RequestMapping("/stades")
public class StadeController {

    @Autowired
    StadeService ss;

    @PostMapping("createstade")
    public Stade addStade(@RequestBody Stade g) {
        return ss.addStade(g);
    }

    @GetMapping("stade")
    List<Stade> getAllStades(){
        return ss.getAllStades();
    }


    @GetMapping("stade/{id}")
    public Stade getStadeById(@PathVariable Long id) {
        return ss.getStadeById(id);

    }

    @GetMapping("stade/{id}/matche")
    public List<Matche> getMatcheByStadeId(@PathVariable Long id) {

        return ss.getMatcheByStadeId(id);
    }

    @PostMapping("stade/{id}/matche/{id2}")
    public Matche addMatcheTostade(@PathVariable Long id, @RequestBody Matche m, @PathVariable Long id2) {
        return ss.addMatcheTostade(id, m, id2);
    }

    @DeleteMapping("stade/{id}")
    public void deleteStade(@PathVariable Long id) {
        ss.deleteStade(id);
    }

    @PutMapping("stade")
    public Stade updateStade(@RequestBody Stade s) {
        return ss.updateStade(s);
    }

}
