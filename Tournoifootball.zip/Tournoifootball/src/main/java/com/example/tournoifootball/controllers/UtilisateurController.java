package com.example.tournoifootball.controllers;

import com.example.tournoifootball.entities.Utilisateur;
import com.example.tournoifootball.services.UtilisateurService;
import lombok.AllArgsConstructor;

import org.springframework.web.bind.annotation.*;

@AllArgsConstructor
@RestController
@RequestMapping("/api/utilisateurs")
public class UtilisateurController {

    private UtilisateurService utilisateurService;

    @PostMapping("/creer")
    public Utilisateur creerUtilisateur(@RequestBody Utilisateur utilisateur) {
        return utilisateurService.save(utilisateur);
    }

    @GetMapping("/{username}")
    public Utilisateur getUtilisateurByUsername(@PathVariable String username) {
        return utilisateurService.findByUsername(username);
    }
}
