package com.example.tournoifootball.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.tournoifootball.entities.Arbitre;
import com.example.tournoifootball.entities.Matche;

import com.example.tournoifootball.services.ArbitreService;

@RestController
@RequestMapping("/arbitres")
public class ArbitreController {

    @Autowired
    ArbitreService as;


    @PostMapping("arbitre")
    public Arbitre addArbitre(@RequestBody Arbitre g) {
        return as.addArbitre(g);
    }

    @PostMapping("arbitre/{id}/matche/{id2}")
    public Matche addMatcheToArbitre(@PathVariable Long id, @RequestBody Matche m, @PathVariable Long id2) {

        return as.addMatcheToArbitre(id, m, id2);}


    @GetMapping("arbitre")
    List<Arbitre> getAllArbitres(){
        return as.getAllArbitres();
    }


    @GetMapping("arbitre/{id}")
    public Arbitre getArbitreById(@PathVariable Long id) {
        return as.getArbitreById(id);

    }

    @GetMapping("arbitre/{id}/matche")
    public List<Matche> getMatcheByarbitreId(@PathVariable Long id) {

        return as.getMatcheByarbitreId(id);
    }

    @DeleteMapping("arbitre/{id}")
    public void deleteArbitre(@PathVariable Long id) {
        as.deleteArbitre(id);
    }

    @PutMapping("arbitre")
    public Arbitre updateArbitre(@RequestBody Arbitre s) {
        return as.updateArbitre(s);
    }
}


