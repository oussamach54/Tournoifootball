package com.example.tournoifootball.services;

import com.example.tournoifootball.entities.Utilisateur;
import com.example.tournoifootball.repositories.UtilisateurRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class UtilisateurService {

    private UtilisateurRepository utilisateurRepository;

    public Utilisateur findByUsername(String username) {
        return utilisateurRepository.findByUsername(username);
    }

    public Utilisateur save(Utilisateur utilisateur) {
        return utilisateurRepository.save(utilisateur);
    }
}
