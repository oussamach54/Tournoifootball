package com.example.tournoifootball;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TournoifootballApplication {

    public static void main(String[] args) {
        SpringApplication.run(TournoifootballApplication.class, args);
    }

}
