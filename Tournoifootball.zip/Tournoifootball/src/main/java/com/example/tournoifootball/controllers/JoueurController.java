package com.example.tournoifootball.controllers;

import java.util.List;

import lombok.AllArgsConstructor;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.example.tournoifootball.services.JoueurService;
import com.example.tournoifootball.entities.Joueur;
@AllArgsConstructor
@RestController
@Controller
public class JoueurController {


    JoueurService ss;
    @RequestMapping("/createJoueur")
    public String createJoueur() {
        return "CreateJoueur";
    }
    @GetMapping("joueur")
    public List<Joueur> getAllJoueurs(){
        return ss.getAllJoueurs();
    }
    @PostMapping("saveJoueur")
    public Joueur saveJoueur(@RequestBody Joueur s) {
        return ss.saveJoueur(s);
    }
    @DeleteMapping("joueur/{id}")
    public void deleteJoueur(@PathVariable Long id) {
        ss.deleteJoueur(id);
    }
    @PutMapping("joueur")
    public Joueur updateJoueur(@RequestBody Joueur s) {
        return ss.updateJoueur(s);
    }
}

