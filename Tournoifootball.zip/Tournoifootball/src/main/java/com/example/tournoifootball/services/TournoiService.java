package com.example.tournoifootball.services;

import com.example.tournoifootball.entities.Tournoi;
import com.example.tournoifootball.repositories.TournoiRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TournoiService {

    @Autowired
    private TournoiRepository tournoiRepository;

    public List<Tournoi> getAllTournois() {
        return tournoiRepository.findAll();
    }

    public Tournoi getTournoiById(Long id) {
        return tournoiRepository.findById(id).orElse(null);
    }

    public Tournoi createTournoi(Tournoi tournoi) {
        return tournoiRepository.save(tournoi);
    }

    public Tournoi updateTournoi(Long id, Tournoi tournoi) {
        if (tournoiRepository.existsById(id)) {
            tournoi.setId(id);
            return tournoiRepository.save(tournoi);
        }
        return null;
    }

    public void deleteTournoi(Long id) {
        tournoiRepository.deleteById(id);
    }
}
