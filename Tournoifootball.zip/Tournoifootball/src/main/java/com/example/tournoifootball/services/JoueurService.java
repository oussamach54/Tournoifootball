package com.example.tournoifootball.services;

import java.util.List;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;


import com.example.tournoifootball.entities.Joueur;
import com.example.tournoifootball.repositories.JoueurRepository;
@AllArgsConstructor
@Service
public class JoueurService {


    JoueurRepository jr;

    public List<Joueur> getAllJoueurs(){
        return jr.findAll();
    }
    public Joueur saveJoueur( Joueur s) {
        return jr.save(s);
    }
    public void deleteJoueur( Long id) {
        jr.deleteById(id);
    }
    public Joueur updateJoueur( Joueur s) {
        return jr.save(s);
    }
}
