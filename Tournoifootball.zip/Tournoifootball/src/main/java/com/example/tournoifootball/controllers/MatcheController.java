package com.example.tournoifootball.controllers;


import java.time.LocalDate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import com.example.tournoifootball.entities.Equipe;
import com.example.tournoifootball.entities.Matche;
import com.example.tournoifootball.entities.Stade;
import com.example.tournoifootball.services.MatcheService;




@RestController
@RequestMapping("/matches")
public class MatcheController {

    @Autowired
    MatcheService ms;

    @GetMapping("matche")
    public List<Matche> getAllMatches(){
        return ms.getAllMatches();
    }

    @GetMapping("matche/{id}")
    public Matche getMatcheById(@PathVariable Long id) {
        return ms.getMatcheById(id);
    }

    @GetMapping("matche/{id}/stade")
    public Stade getStadeByMatcheId(@PathVariable Long id) {
        return ms.getStadeByMatcheId(id);
    }
    @GetMapping("matche/{id}/equipes")
    public List<Equipe> getEquipesByMatcheId(@PathVariable Long id) {
        return ms.getEquipesByMatcheId(id);

    }

    @GetMapping("matche/date/{date}")
    public List<Matche> findByDateMatchEquals(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {

        return ms.findByDateMatchEquals(date);

    }
    @PostMapping("matche")
    public Matche addMatche(@RequestBody Matche s) {
        return ms.addMatche(s);
    }

    @PutMapping("matche")
    public Matche updateMatche(@RequestBody Matche s) {
        return ms.updateMatche(s);
    }

    @DeleteMapping("matche/{id}")
    public void deleteMatche(@PathVariable Long id) {
        ms.deleteMatche(id);
    }

    @DeleteMapping("matche")
    public List<Matche> deleteMatchesLessThanNow() {
        return ms.deleteMatchesLessThanNow();
    }

    public List<Matche> getAllMatches(int page, int size, String feild){
        return ms.getAllMatches(page, size, feild);
    }
}
